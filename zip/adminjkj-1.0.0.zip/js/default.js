var richNavTabs;

function MyWork(){
	var date = new Date();
	return '我的工作台' + date.toLocaleDateString() + date.toLocaleTimeString();
}
$(function(){
	richNavTabs = $.jkj.richNavTabs();
	
    //新开导航标签
    $('a[data-type="menu"]').on('click',function(e){
    	e.preventDefault();
    	var menuId = $(this).attr("data-id"),
    		menuUrl = $(this).attr("data-src"),
    		menuTitle = $(this).text();
    		menuFullTitle = $(this).attr("data-title")||menuTitle;
    	richNavTabs.addNavTab(menuId, menuTitle, 'page', menuUrl, true, menuFullTitle);
    });
    $(".sidebar-toggle").click(function(){
    	alert(1);
    	var isScale = $("body").hasClass("sidebar-collapse");alert(isScale);
    	$(this).find(".fa-caret-left").hide();
    	$(this).find(".fa-caret-right").show();
    });
    
    window.open('/AdminJKJ/src/pages/home/orderDefault.html','订单管理','',true);
});
$(window).on('load', function () {
	$('#pageTabs').richNavTabs.addNavTab('home','我的工作台','content','MyWork',false,'我的工作台');
	//$('#pageTabs').richNavTabs.addNavTab('baidu','百度','page','http://www.baidu.com',true,'我的百度');
	//richNavTabs.addNavTab('nunjucks','nunjucks','page','http://mozilla.github.io/nunjucks/getting-started.html',true,'前端js模板引擎');
});
